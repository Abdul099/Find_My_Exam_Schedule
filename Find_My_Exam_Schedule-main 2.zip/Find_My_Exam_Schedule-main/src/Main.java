import java.io.IOException;
import java.util.*;
class Main {
    public static void main(String args[]) {
        //Backend backend = new Backend();
        //UI ui = new UI(backend);
        //ArrayList<String> courseList = ui.getInputCourseList();
        ArrayList<String> courseList = new ArrayList<>();
        ArrayList<String> sectionList = new ArrayList<>();
        courseList.add("ACCT 351");
        /*courseList.add("COMP 208");
        courseList.add("COMP 250");
        courseList.add("COMP 251");*/
        sectionList.add("1");
        /*sectionList.add("1");
        sectionList.add("1");
        sectionList.add("1");*/

        ExamSchedule userSchedule = new ExamSchedule();

        /*try{
            for(int i=0; i<courseList.size(); i++) {
                userSchedule.addExam(csvReader.searchCourseCsv(courseList.get(i),sectionList.get(i)));
            }
        }
        catch (IOException e){
            System.out.println("CSV file reading unsuccessful");
        }*/

        Exam heyyo = new Exam ("COMP 208", "1", "Computers", "12/17/2019", "14:00", "GYM FIELDHOUSE");
        Exam heyyo2 = new Exam ("MATH 263", "2", "ODEs", "12/16/2019", "14:00", "GYM FIELDHOUSE");
        userSchedule.addExam(heyyo);
        userSchedule.addExam(heyyo2);

        System.out.println("Here is the list of your exams:\n");
        userSchedule.printSchedule();
    }

}